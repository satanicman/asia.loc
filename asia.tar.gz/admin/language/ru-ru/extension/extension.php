<?php
// Heading
$_['heading_title']  = 'Модули / Расширения';

// Text
$_['text_success']   = 'Настройки успешно изменены!';
$_['text_list']      = 'Расширения';
$_['text_type']      = 'Выберите тип расширения';
$_['text_filter']    = 'Фильтр';
$_['text_analytics'] = 'Аналитика';
$_['text_captcha']   = 'Защита от роботов';
$_['text_dashboard'] = 'Панель управления';
$_['text_feed']      = 'Продвижение';
$_['text_fraud']     = 'Защита от мошенников';
$_['text_module']    = 'Модули';
$_['text_content']   = 'Текстовые модули';
$_['text_menu']      = 'Меню';
$_['text_payment']   = 'Оплата';
$_['text_shipping']  = 'Доставка';
$_['text_theme']     = 'Темы';
$_['text_total']     = 'Учитывать в заказе';

